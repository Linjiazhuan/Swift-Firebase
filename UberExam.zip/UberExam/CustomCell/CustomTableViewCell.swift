//
//  CustomTableViewCell.swift
//  UberExam
//
//  Created by Apple on 2019/5/8.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    
    @IBOutlet weak var userImage:UIImageView!
    @IBOutlet weak var emailLabel:UILabel!
    @IBOutlet weak var descriptionLabel:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configureCell(image:UIImage,email:String, description:String){
        userImage.image = image
        emailLabel.text = email
        descriptionLabel.text = description
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
