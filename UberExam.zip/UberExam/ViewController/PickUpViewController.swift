//
//  PickUpViewController.swift
//  UberExam
//
//  Created by Apple on 2019/5/6.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import MapKit
import FirebaseDatabase
import CoreLocation

class PickUpViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    var riderEmail = ""
    var riderLocation = CLLocationCoordinate2D()
    var driverLocation = CLLocationCoordinate2D()
    var locationManager = CLLocationManager()
    let reference = Database.database().reference()
    
    @IBOutlet weak var mapView:MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        mapView.delegate = self
        locationManager.delegate = self
        
        getRiderLocation()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func backButtonPressed(sender:UIBarButtonItem){
    }
    
    @IBAction func pickUpRequest(_ sender:UIButton){
        reference.child("RiderRequests").queryOrdered(byChild: "email").queryEqual(toValue: riderEmail).observeSingleEvent(of: DataEventType.childAdded) { (dataSnapShot) in
            dataSnapShot.ref.updateChildValues(["driverLat":self.driverLocation.latitude, "driverLog":self.driverLocation.longitude,])
            
            let riderCLLocation = CLLocation(latitude: self.riderLocation.latitude, longitude: self.riderLocation.longitude)
            CLGeocoder().reverseGeocodeLocation(riderCLLocation, completionHandler: { (clplacemarks, error) in
                if let placemaks = clplacemarks{
                    if placemaks.count > 0{
                        let placemark = MKPlacemark(placemark: placemaks[0])
                        let mapItem = MKMapItem(placemark: placemark)
                        mapItem.name = self.riderEmail
                        
                        mapItem.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey :MKLaunchOptionsDirectionsModeDriving ])
                    }
                }
            })
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {

    }
    
    func getRiderLocation(){
        let riderAnnotation = MKPointAnnotation()
        riderAnnotation.coordinate = riderLocation
        let span = MKCoordinateSpan(latitudeDelta: 0.0018, longitudeDelta: 0.0018)
        let region = MKCoordinateRegion(center: riderLocation, span: span)
        mapView.setRegion(region, animated: true)
        riderAnnotation.title = riderEmail
        mapView.addAnnotation(riderAnnotation)
    }
}

