//
//  DriverTableViewController.swift
//  UberExam
//
//  Created by Apple on 2019/5/6.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import MapKit
import FirebaseAuth
import FirebaseDatabase

class DriverTableViewController: UITableViewController, CLLocationManagerDelegate {

//    @IBOutlet weak var SignOutButton:UIBarButtonItem!
    var riderRequests:[DataSnapshot] = []
    var reference = Database.database().reference()
    var driverLocation = CLLocationCoordinate2D()
    var locationManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        locationManager.delegate = self
        
        retrieveData()
        
        getDriverLocation()
        
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (timer) in
            self.tableView.reloadData()
        }
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    func getDriverLocation(){
        if CLLocationManager.authorizationStatus() == CLAuthorizationStatus.notDetermined{
            locationManager.requestAlwaysAuthorization()
        }else{
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
        }
    }
    
    @IBAction func SignOutPressed(sender:UIBarButtonItem){
        do{
            try Auth.auth().signOut()
            navigationController?.dismiss(animated: true, completion: nil)
        }catch{
            print(error)
        }
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let coordinate = manager.location?.coordinate{
            driverLocation = coordinate
        }
    }
    
    func retrieveData(){
        reference.child("RiderRequests").observe(DataEventType.childAdded) { (dataSnapShot) in
            if let riderRequestDic = dataSnapShot.value as? [String:Any]{
                self.riderRequests.append(dataSnapShot)
                self.tableView.reloadData()
            }
        }
    }

    // MARK: - Table view data source



    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return riderRequests.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! CustomTableViewCell
        let snapShot = riderRequests[indexPath.row]
        
        if let riderRequestDic = snapShot.value as? [String:Any]{
            if let email = riderRequestDic["email"] as? String{
                if let latitude = riderRequestDic["latitude"] as? Double{
                    if let longtitude = riderRequestDic["longitude"] as? Double{
                        let riderCLLocation = CLLocation(latitude: latitude, longitude: longtitude)
                        let driverCLLocation = CLLocation(latitude: driverLocation.latitude, longitude: driverLocation.longitude)
                        let distance = riderCLLocation.distance(from: driverCLLocation) / 100
                        let roundedDistance = round(distance * 100) / 100
                        let detail = "\(roundedDistance)km"
                        if let image = UIImage(named: "usericon"){
                            cell.configureCell(image: image, email: email, description: detail)
                        }
                    }
                }
            }
        }
        // Configure the cell...

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let snapShot = riderRequests[indexPath.row]
        performSegue(withIdentifier: "pickupSegue", sender: snapShot)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "pickupSegue"{
            let pickupViewController = segue.destination as! PickUpViewController
            if let snapShot = sender as? DataSnapshot{
                if let riderRequests = snapShot.value as? [String:Any]{
                    if let email = riderRequests["email"] as? String{
                        if let latitude = riderRequests["latitude"] as? Double{
                            if let longitude = riderRequests["longitude"] as? Double{
                                pickupViewController.riderEmail = email
                                pickupViewController.riderLocation = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
                                pickupViewController.driverLocation = driverLocation
                            }
                        }
                    }
                }
            }
        }
    }
}
