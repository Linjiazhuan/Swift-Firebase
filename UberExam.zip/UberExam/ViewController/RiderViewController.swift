//
//  RiderViewController.swift
//  UberExam
//
//  Created by Apple on 2019/5/6.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import FirebaseDatabase
import FirebaseAuth

class RiderViewController: UIViewController , MKMapViewDelegate, CLLocationManagerDelegate{

    let locationManager = CLLocationManager()
    var reference = Database.database().reference()
    var driverLocation = CLLocationCoordinate2D()
    var hasCallUber:Bool = false
    var userLocation = CLLocationCoordinate2D()
    
    @IBOutlet weak var CallAnUberButton:UIButton!
    @IBOutlet weak var mapView:MKMapView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        locationManager.delegate = self
        if CLLocationManager.authorizationStatus() == CLAuthorizationStatus.notDetermined{
            locationManager.requestAlwaysAuthorization()
        }else{
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
        }
        
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (timer) in
            self.updateDriverLocation()
        }

        // Do any additional setup after loading the view.
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let coordinate = manager.location?.coordinate{
            userLocation = coordinate
            
            
            if hasCallUber{
                displayDriverAndRider()
            }else{
                let region = MKCoordinateRegion(center: coordinate, latitudinalMeters: 1, longitudinalMeters: 1)
                mapView.setRegion(region, animated: true)
                mapView.removeAnnotations(mapView.annotations)
                
                let annotation = MKPointAnnotation()
                annotation.coordinate = coordinate
                annotation.title = "My location"
                mapView.addAnnotation(annotation)
            }
        }



    }
    
    
    @IBAction func CallUberButtonPressed(sender:UIButton){
        if let email = Auth.auth().currentUser?.email{
            if hasCallUber{

                reference.child("RiderRequests").queryOrdered(byChild: "email").queryEqual(toValue: email).observe(DataEventType.childAdded) { (dataSnapShot) in
                    
                    dataSnapShot.ref.removeValue()
                    self.reference.child("RiderRequests").removeAllObservers()
                }
                cancelUber()
            }else{

                let riderRequestDic:[String:Any] = ["email":email, "latitude":userLocation.latitude,"longitude":userLocation.longitude]
                reference.child("RiderRequests").childByAutoId().setValue(riderRequestDic)
                callUber()
            }
        }

    }
    func cancelUber(){
        CallAnUberButton.setTitle("Call An Uber", for: .normal)
        CallAnUberButton.backgroundColor = #colorLiteral(red: 0.1368798702, green: 0.8682534741, blue: 0.09411979973, alpha: 1)
        hasCallUber = false

        
    }
    func callUber(){

            CallAnUberButton.setTitle("Cancel Uber", for: .normal)
            CallAnUberButton.backgroundColor = #colorLiteral(red: 0.5725490451, green: 0, blue: 0.2313725501, alpha: 1)
            hasCallUber = true

    }
    
    @IBAction func SignOutPressed(sender:UIBarButtonItem){
        do{
            try Auth.auth().signOut()
            navigationController?.dismiss(animated: true, completion: nil)
        }catch{
            
        }
    }
    
    func updateDriverLocation(){
        if let email = Auth.auth().currentUser?.email{
            reference.child("RiderRequests").queryOrdered(byChild: "email").queryEqual(toValue: email).observe(.childAdded) { (dataSnapShot) in
                if let riderRequestDic = dataSnapShot.value as? [String:Any]{
                    if let driverLat = riderRequestDic["driverLat"] as? Double{
                        if let driverLog = riderRequestDic["driverLog"] as? Double{
                            self.driverLocation = CLLocationCoordinate2D(latitude: driverLat, longitude: driverLog)
                            self.hasCallUber = true
                            self.displayDriverAndRider()
                            self.reference.ref.removeAllObservers()
                        }
                    }
                }
            }
        }
    }
    
    
    func displayDriverAndRider(){
        let driverCLLocation = CLLocation(latitude: driverLocation.latitude, longitude: driverLocation.longitude)
        let riderCLLocation = CLLocation(latitude: userLocation.latitude, longitude: userLocation.longitude)
        let distance = riderCLLocation.distance(from: driverCLLocation) / 1000
        let roundedDistance = round(distance * 100) / 100
        CallAnUberButton.setTitle("Your driver is \(roundedDistance) KM", for: .normal)
        
        mapView.removeAnnotations(mapView.annotations)
        
        let riderAnnotation = MKPointAnnotation()
        riderAnnotation.coordinate = userLocation
        riderAnnotation.title = "Your location"
        mapView.addAnnotation(riderAnnotation)
        
        let driverAnnotation = MKPointAnnotation()
        driverAnnotation.coordinate = driverLocation
        driverAnnotation.title = "Driver location"
        mapView.addAnnotation(driverAnnotation)
        
        let region = MKCoordinateRegion(center: userLocation, span: MKCoordinateSpan(latitudeDelta: 0.003, longitudeDelta: 0.003))
        mapView.setRegion(region, animated: true)
    }
}
