//
//  ViewController.swift
//  UberExam
//
//  Created by Apple on 2019/5/6.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import FirebaseCore
import FirebaseAuth


class ViewController: UIViewController {

    @IBOutlet weak var emailTextfield:UITextField!
    @IBOutlet weak var passwordTextfield:UITextField!
    @IBOutlet weak var userSwitch:UISwitch!
    @IBOutlet weak var signInButton:UIButton!
    @IBOutlet weak var SignView:UIView!{
        didSet{
            self.SignView.layer.cornerRadius = 10
            self.SignView.layer.masksToBounds = true
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        cumtomerTextfield(textfield: emailTextfield, iconName: "usericon")
        cumtomerTextfield(textfield: passwordTextfield, iconName: "passwordIcon")
        // Do any additional setup after loading the view.
    }
    
    //MARK: IBAction
    
    @IBAction func changeSignInButton(sender:UISwitch){
        if userSwitch.isOn{
            signInButton.backgroundColor = #colorLiteral(red: 0.2196078449, green: 0.007843137719, blue: 0.8549019694, alpha: 1)
            signInButton.setTitle("Rider Sign In", for: .normal)
        }else{
            signInButton.backgroundColor = #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1)
            signInButton.setTitle("Driver Sign In", for: .normal)
        }
    }
    
    @IBAction func signInButtonPressed(sender:UIButton){
        if let email = emailTextfield.text, email != ""{
            if let password = passwordTextfield.text, password != ""{
                Auth.auth().signIn(withEmail: email, password: password) { (result, error) in
                    if let error = error{
                        if let errorString = (error as! NSError).userInfo["error_name"] as? String{
                            switch errorString{
                            case "ERROR_USER_NOT_FOUND":
                                if self.userSwitch.isOn{
                                    Auth.auth().createUser(withEmail: email, password: password, completion: { (result, error) in
                                        guard  error == nil else{
                                            self.displayAlert(title: nil, message: "The password must be 6 characters long or more")
                                            return
                                        }
                                        let chagneRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                                        chagneRequest?.displayName = "Rider"
                                        chagneRequest?.commitChanges(completion: nil)
                        
                                        self.performSegue(withIdentifier: "riderSegue", sender: self)
                                    })
                                }else{
                                    Auth.auth().createUser(withEmail: email, password: password, completion: { (result, error) in
                                        guard  error == nil else{
                                            self.displayAlert(title: nil, message: "The password must be 6 characters long or more")
                                            return
                                        }
                                        let chagneRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                                        chagneRequest?.displayName = "Driver"
                                        chagneRequest?.commitChanges(completion: nil)
                                        self.performSegue(withIdentifier: "driverSegue", sender: self)

                                    })
                                }

                            case "ERROR_INVALID_EMAIL":
                                self.displayAlert(title: nil, message: "Your email formatt is wrong")
                            default:
                                break
                            }
                        }
                        
                    }else{
                        let user = Auth.auth().currentUser
                        if user?.displayName == "Rider"{
                            self.performSegue(withIdentifier: "riderSegue", sender: self)
                        }else{
                            self.performSegue(withIdentifier: "driverSegue", sender: self)
                        }
                    }
                }
            }else{
                displayAlert(title: nil, message: "Please fill your password")
            }
        }else{
            displayAlert(title: nil, message: "Please fill your email")
        }
    }
    func displayAlert(title:String?, message:String?){
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let alertAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(alertAction)
        present(alertController, animated: true, completion: nil)
    }
    

    
    
    
    //MARK: Customber IBOutlet
    
    func cumtomerTextfield(textfield:UITextField, iconName:String){
//        textfield.layer.cornerRadius = textfield.frame.height / 2
//        textfield.clipsToBounds = true
        
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 30, height: 30))
        imageView.image = UIImage(named: iconName)
        imageView.contentMode = .scaleAspectFit
        textfield.leftViewMode = UITextField.ViewMode.always
        textfield.leftView = imageView
        
    }
    
    

}



